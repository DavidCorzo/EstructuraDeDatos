package com.sumn.sumnwithrest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SumnwithrestApplicationTests {

	@Test
	void contextLoads() {
	}

}
