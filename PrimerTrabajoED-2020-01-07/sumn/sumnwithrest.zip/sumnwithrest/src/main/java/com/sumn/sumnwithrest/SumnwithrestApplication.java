package com.sumn.sumnwithrest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SumnwithrestApplication {

	public static void main(String[] args) {
		SpringApplication.run(SumnwithrestApplication.class, args);
	}

}
