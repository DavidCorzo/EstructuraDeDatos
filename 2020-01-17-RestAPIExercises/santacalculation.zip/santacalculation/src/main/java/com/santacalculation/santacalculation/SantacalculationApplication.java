package com.santacalculation.santacalculation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SantacalculationApplication {

	public static void main(String[] args) {
		SpringApplication.run(SantacalculationApplication.class, args);
	}

}
